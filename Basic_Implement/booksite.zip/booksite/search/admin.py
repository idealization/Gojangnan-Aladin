from django.contrib import admin

# Register your models here.
from .models import Question, Book
# 해당 폴더의 models.py 의 파일에서 Question 이란 class 를 import


class QuestionAdmin(admin.ModelAdmin):
    search_fields = ['subject']


admin.site.register(Question, QuestionAdmin)


class BookAdmin(admin.ModelAdmin):
    search_fields = ['subject']


admin.site.register(Book, BookAdmin)

