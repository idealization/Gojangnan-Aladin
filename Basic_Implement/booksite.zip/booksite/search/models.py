from django.db import models
from django.contrib.auth.models import User
# Create your models here.


# === 점프 투 장고 예시
class Question(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    subject = models.CharField(max_length=200)
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True) #수정된 것


    def __str__(self):
        return self.subject #subject를 반환하는 함수


class Answer(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE) #외래 키를 가진다. 질문 삭제되면 답변도 같이 삭제됨
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True) # 수정

    #def __str__(self):
        #return self.content #어떤 내용이 있는지를 반환하는 함수





class Book(models.Model):
    ISBN = models.IntegerField()
    title = models.TextField(null = True)
    original_title = models.TextField()
    price = models.IntegerField()
    author = models.TextField()
    published_year = models.TextField()
    language = models.TextField()
    image_url = models.TextField()

    def __str__(self):
        return self.title #subject를 반환하는 함수









