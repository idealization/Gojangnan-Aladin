from django.core.paginator import Paginator
from django.shortcuts import render, get_object_or_404

from ..models import Question, Book
from django.db.models import Q

def index(request):
    """
    질문 목록 출력
    """
    # 입력 파라미터
    page = request.GET.get('page', '1')  # 페이지
    kw = request.GET.get('kw', '')  # 검색어

    # 조회
    #question_list = Question.objects.order_by('-create_date') # create date의 역순으로 정렬됨

    book_list = Book.objects.order_by('-title')  # create date의 역순으로 정렬됨

    if kw:
        book_list = book_list.filter(
            Q(title__icontains=kw) |  # 제목검색
            Q(ISBN__icontains=kw) |  # 내용검색
            Q(author__icontains=kw) |  # 질문 글쓴이검색
            Q(original_title__icontains=kw)  # 답변 글쓴이검색
        ).distinct()


    # 페이징처리
    #paginator = Paginator(question_list, 20)  # 페이지당 20개씩 보여주기
    paginator = Paginator(book_list, 20)  # 페이지당 20개씩 보여주기
    page_obj = paginator.get_page(page)

    #context = {'question_list': page_obj}
    #context = {'question_list': page_obj, 'page': page, 'kw': kw}  # page와 kw가 추가되었다.

    #context = {'question_list': question_list}

    context = {'book_list': page_obj, 'page': page, 'kw': kw}  # page와 kw가 추가되었다.
    return render(request, 'search/book_list.html', context) # render 함수는 html 파일로 변환한다.







'''
def detail(request, question_id):
    #question = Question.objects.get(id=question_id) 오류가 나타냈을 때 404를 출력하지 않는다
    question = get_object_or_404(Question, pk=question_id) # 404 페이지를 나타나게 한다.
    context = {'question': question}
    return render(request, 'search/book_detail.html', context)'''

def detail(request, book_isbn):
    #book = Book.objects.get(ISBN =book_isbn)
    book = get_object_or_404(Book, ISBN = book_isbn) # 404 페이지를 나타나게 한다.
    context = {'book': book}
    return render(request, 'search/book_detail.html', context)